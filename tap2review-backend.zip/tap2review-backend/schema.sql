-- ============================================================================
-- Tap2Review — database schema
-- Run this in the Supabase SQL editor (or as a migration).
-- Compliance note: there is NO star-rating gate anywhere in this schema.
-- A card points either to Google (everyone) or to the neutral hub (everyone).
-- ============================================================================

-- Needed for gen_random_uuid()
create extension if not exists "pgcrypto";

-- ----------------------------------------------------------------------------
-- businesses: one row per client location
-- ----------------------------------------------------------------------------
create table if not exists businesses (
  id                    uuid primary key default gen_random_uuid(),
  name                  text not null,
  google_place_id       text,                 -- used by sync-reviews (Places API)
  -- Direct "write a review" deep link. If left null, the redirect function
  -- falls back to the standard Google writereview URL built from place_id:
  --   https://search.google.com/local/writereview?placeid=PLACE_ID
  review_url            text,
  -- Where the hub's "contact us / share feedback" button points.
  -- Can be a mailto:, tel:, a support form URL, or a manager's page.
  feedback_url          text,
  current_review_count  int,                  -- latest snapshot, denormalized for speed
  current_rating        numeric(2,1),         -- latest snapshot
  reviews_synced_at     timestamptz,
  created_at            timestamptz not null default now()
);

-- ----------------------------------------------------------------------------
-- cards: one row per physical item (stand, placard, badge, etc.)
-- The NFC tag / QR always encodes:  https://<your-domain>/r/<slug>
-- ----------------------------------------------------------------------------
create table if not exists cards (
  id           uuid primary key default gen_random_uuid(),
  business_id  uuid not null references businesses(id) on delete cascade,
  slug         text not null unique,          -- short code in the URL, e.g. 'a1b2c3'
  label        text,                          -- 'Front counter', 'Table 4', 'Manager badge'
  card_type    text default 'stand',          -- stand | placard | badge | card
  -- 'google' = 302 straight to the review page (everyone)
  -- 'hub'    = show the neutral two-button page (everyone, same options)
  destination  text not null default 'google'
                 check (destination in ('google','hub')),
  active       boolean not null default true,
  created_at   timestamptz not null default now()
);

create index if not exists idx_cards_business on cards(business_id);

-- ----------------------------------------------------------------------------
-- taps: append-only event log. NO raw IP is stored (privacy by design).
-- ----------------------------------------------------------------------------
create table if not exists taps (
  id           bigint generated always as identity primary key,
  card_id      uuid not null references cards(id) on delete cascade,
  business_id  uuid not null references businesses(id) on delete cascade,
  created_at   timestamptz not null default now(),
  device_type  text,                          -- ios | android | other
  os           text,                          -- iOS | Android | Windows | macOS | ...
  country      text,                          -- coarse, best-effort, may be null
  referer      text,
  is_repeat    boolean default false          -- reserved for future dedupe logic
);

create index if not exists idx_taps_business_time on taps(business_id, created_at);
create index if not exists idx_taps_card_time     on taps(card_id, created_at);

-- ----------------------------------------------------------------------------
-- review_snapshots: one row per business per day (idempotent upsert)
-- ----------------------------------------------------------------------------
create table if not exists review_snapshots (
  id            bigint generated always as identity primary key,
  business_id   uuid not null references businesses(id) on delete cascade,
  captured_on   date not null default (now() at time zone 'utc')::date,
  review_count  int,
  rating        numeric(2,1),
  created_at    timestamptz not null default now(),
  unique (business_id, captured_on)
);

create index if not exists idx_snapshots_business on review_snapshots(business_id, captured_on);

-- ----------------------------------------------------------------------------
-- contacts: decision-maker / billing contacts captured during the sale
-- (receipts, dashboard login, "who to call if it breaks", guarantee)
-- ----------------------------------------------------------------------------
create table if not exists contacts (
  id           uuid primary key default gen_random_uuid(),
  business_id  uuid not null references businesses(id) on delete cascade,
  name         text,
  title        text,
  email        text,
  phone        text,
  role         text,                          -- owner | manager | billing | support
  is_primary   boolean default false,
  notes        text,
  created_at   timestamptz not null default now()
);

create index if not exists idx_contacts_business on contacts(business_id);

-- ----------------------------------------------------------------------------
-- Dashboard helper views
-- ----------------------------------------------------------------------------

-- Daily tap totals per business
create or replace view daily_taps as
select
  business_id,
  (created_at at time zone 'utc')::date as day,
  count(*)                              as taps
from taps
group by business_id, (created_at at time zone 'utc')::date;

-- Taps broken out by card (which placement is working hardest)
create or replace view taps_by_card as
select
  c.business_id,
  c.id     as card_id,
  c.label,
  c.card_type,
  count(t.id) as taps
from cards c
left join taps t on t.card_id = c.id
group by c.business_id, c.id, c.label, c.card_type;

-- ----------------------------------------------------------------------------
-- Row Level Security
-- Edge functions use the SERVICE ROLE key, which bypasses RLS.
-- We enable RLS and add NO public policies, so the anon key can't read/write
-- these tables directly. When you build the dashboard, add read policies
-- scoped to authenticated users (example commented below).
-- ----------------------------------------------------------------------------
alter table businesses       enable row level security;
alter table cards            enable row level security;
alter table taps             enable row level security;
alter table review_snapshots enable row level security;
alter table contacts         enable row level security;

-- Example policy to enable later, once the dashboard has auth + a way to map
-- a logged-in user to a business (e.g. a memberships table):
--
-- create policy "members read their business taps"
--   on taps for select to authenticated
--   using ( business_id in (
--     select business_id from memberships where user_id = auth.uid()
--   ) );
