# Tap2Review — redirect / hub / analytics backend

Four pieces, all on Supabase. No star-rating gate anywhere — every card sends
all customers to the same place (Google review page, or the neutral hub), which
is what keeps clients compliant with Google + FTC rules.

```
schema.sql                          → tables, views, RLS
supabase/functions/redirect/        → logs the tap, 302s onward   (public)
supabase/functions/hub/             → neutral two-button page      (public)
supabase/functions/sync-reviews/    → daily review-count snapshot  (secret-guarded)
```

## 1. Create the schema
Paste `schema.sql` into the Supabase SQL editor and run it.

## 2. Set function secrets
```bash
supabase secrets set \
  GOOGLE_PLACES_API_KEY=xxxxx \
  CRON_SECRET=$(openssl rand -hex 24) \
  FALLBACK_URL=https://your-marketing-site.com \
  HUB_BASE_URL=https://<project-ref>.functions.supabase.co/hub
```
`SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` are injected automatically.

## 3. Deploy the functions
```bash
supabase functions deploy redirect     --no-verify-jwt
supabase functions deploy hub          --no-verify-jwt
supabase functions deploy sync-reviews --no-verify-jwt   # guarded by CRON_SECRET
```

## 4. Point a pretty domain at the redirect (optional but do it)
You want the printed URL to read `tap2review.com/r/a1b2c3`, not a long Supabase
URL. Put Cloudflare (or any proxy) in front and rewrite:

```
tap2review.com/r/*   →   https://<project-ref>.functions.supabase.co/redirect/*
tap2review.com/hub/* →   https://<project-ref>.functions.supabase.co/hub/*
```
Then set `HUB_BASE_URL=https://tap2review.com/hub`. As a bonus, Cloudflare adds
a `cf-ipcountry` header, which the redirect function stores as coarse country.

## 5. Schedule the daily review sync
In the SQL editor (uses pg_cron + pg_net, both available on Supabase):

```sql
select cron.schedule(
  'daily-review-sync',
  '17 8 * * *',                       -- 08:17 UTC daily; pick an off-peak minute
  $$
  select net.http_post(
    url     := 'https://<project-ref>.functions.supabase.co/sync-reviews',
    headers := jsonb_build_object('x-cron-secret', '<your CRON_SECRET>'),
    body    := '{}'::jsonb
  );
  $$
);
```

## Onboarding a new client (until there's an admin UI)
```sql
-- 1. the business
insert into businesses (name, google_place_id, feedback_url)
values ('Joe''s Pizza', 'ChIJ...placeid...', 'mailto:manager@joespizza.com')
returning id;

-- 2. one card per physical item; slug is what goes on the NFC tag / QR
insert into cards (business_id, slug, label, card_type, destination) values
  ('<business-id>', 'joe-counter', 'Front counter', 'stand',   'google'),
  ('<business-id>', 'joe-t4',      'Table 4',       'placard', 'hub');
```
The NFC tag / QR for the first card encodes: `https://tap2review.com/r/joe-counter`

## What each tap stores (and doesn't)
Stored: card, business, timestamp, device type, OS, coarse country, referer.
**Not** stored: raw IP address, name, or anything that identifies the customer.

## Honesty guardrail
Taps are measured exactly. Review counts are snapshotted daily. You can show
both trends side by side — but you can't attribute a specific review to a
specific tap, so the dashboard should present them as correlated, never causal.
